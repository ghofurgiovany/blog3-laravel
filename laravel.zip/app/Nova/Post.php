<?php

namespace App\Nova;

use Armincms\Json\Json;
use Illuminate\Http\Request;
use Laravel\Nova\Fields\Badge;
use Laravel\Nova\Fields\BelongsTo;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\MorphMany;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Slug;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Laravel\Nova\Http\Requests\NovaRequest;

class Post extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\Models\Post::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'title';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'title',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(Request $request)
    {
        return [
            Slug::make('slug')->onlyOnForms(),
            Text::make('Title')->displayUsing(fn ($title) => \substr($title, 0, 100) . '...'),
            Textarea::make('description'),
            // Textarea::make('keywords')->displayUsing(fn ($k) => implode(", ", $k)),
            // Textarea::make('Paragraph')->displayUsing(fn ($p) => implode("\n\n", $p)),
            Text::make('Language')->displayUsing(fn ($lang) => \strtoupper($lang))->textAlign("center"),
            Number::make('Views')->textAlign('center')->sortable(),
            Number::make('Shares')->textAlign('center'),
            BelongsTo::make('Author')->textAlign('center'),
            MorphMany::make('Categories'),
            MorphMany::make('Country', 'countries'),
            MorphMany::make('Images'),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
