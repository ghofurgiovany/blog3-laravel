// Nova Asset JS
