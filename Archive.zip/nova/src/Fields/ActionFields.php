<?php

namespace Laravel\Nova\Fields;

class ActionFields extends ResolvedFields
{
    //
}
